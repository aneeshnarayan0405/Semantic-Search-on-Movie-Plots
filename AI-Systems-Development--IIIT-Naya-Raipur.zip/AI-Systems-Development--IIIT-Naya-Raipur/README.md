This repository contains the materials related to the "AI Systems development"
